دفتر — نسخة iOS

هذه الحزمة تحتوي على:
- مشروع Xcode لتطبيق iOS باسم «دفتر».
- نسخة HTML الأصلية داخل التطبيق، تعمل محليًا وتحفظ البيانات على الجهاز عبر localStorage.
- دعم مشاركة ملفات JSON/CSV من داخل iPhone عبر نافذة المشاركة في iOS.
- أيقونة تطبيق أولية.

مهم:
لا يمكن إنشاء ملف IPA موقعًا باسم المطور من بيئة غير مرتبطة بحساب Apple/شهادة توقيع. ملف IPA النهائي يحتاج Apple Developer Signing على Xcode أو خدمة توقيع موثوقة.

طريقة البناء على Mac:
1) فك الضغط.
2) افتح Dafter/Dafter.xcodeproj في Xcode.
3) اختر Signing & Capabilities ثم فريق Apple الخاص بك.
4) اختر جهاز iPhone أو Generic iOS Device.
5) Product > Archive لبناء نسخة التوزيع، أو Run للتثبيت على جهازك.
