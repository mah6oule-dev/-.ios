self.addEventListener('install', e => self.skipWaiting());
self.addEventListener('activate', e => self.clients.claim());
self.addEventListener('fetch', e => {
  e.respondWith(caches.open('dafter-v1').then(async c => {
    const cached = await c.match(e.request);
    if (cached) return cached;
    const r = await fetch(e.request);
    if (e.request.method === 'GET' && new URL(e.request.url).origin === location.origin) c.put(e.request, r.clone());
    return r;
  }));
});
